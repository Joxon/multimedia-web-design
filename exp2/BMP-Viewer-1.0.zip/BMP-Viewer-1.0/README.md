# BMP-Viewer
Actually more than BMP

# 题目

北邮《数字媒体内容综合设计与实验》

2. 图像处理...

（2）显示一个bmp文件的 C 程序，并实现图像亮度、对比度调整、图像平移、放大、旋转和镜像。

# 功能

- [x] 显示 QImage->QPixmap->QLabel
- [x] 平移 QScrollArea
- [x] 放大 QImage.scaled(...)
- [x] 旋转 QImage.transformed(...)
- [x] 镜像 QImage.mirrored(...)
- [x] 亮度调整
- [x] 对比度调整
- [ ] 手型工具
- [ ] 滚轮缩放
